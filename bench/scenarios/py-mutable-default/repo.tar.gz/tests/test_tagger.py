import unittest, sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from tagger import add_tag
class T(unittest.TestCase):
    def test_one(self):
        self.assertEqual(add_tag('a', []), ['a'])
if __name__ == '__main__':
    unittest.main()
